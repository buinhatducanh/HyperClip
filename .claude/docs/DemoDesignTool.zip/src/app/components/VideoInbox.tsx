import { useState } from 'react';
import { Channel, Video } from '../types';

interface Props {
  channel: Channel;
  videos: Video[];
  selectedVideoId: string | null;
  onVideoSelect: (video: Video) => void;
}

type Tab = 'new' | 'managed';

function StatusPill({ status, progress }: { status: Video['status']; progress?: number }) {
  if (status === 'new') {
    return (
      <span
        style={{
          fontSize: 8,
          fontWeight: 800,
          color: '#00FF88',
          background: '#00FF8810',
          borderWidth: 1,
          borderStyle: 'solid',
          borderColor: '#00FF8822',
          borderRadius: 2,
          padding: '1px 4px',
          letterSpacing: '0.04em',
        }}
      >
        NEW
      </span>
    );
  }
  if (status === 'rendering') {
    return (
      <span
        style={{
          fontSize: 8,
          fontWeight: 800,
          color: '#00B4FF',
          background: '#00B4FF10',
          borderWidth: 1,
          borderStyle: 'solid',
          borderColor: '#00B4FF22',
          borderRadius: 2,
          padding: '1px 4px',
          letterSpacing: '0.04em',
        }}
      >
        {progress !== undefined ? `${progress}%` : 'RENDERING'}
      </span>
    );
  }
  return (
    <span
      style={{
        fontSize: 8,
        fontWeight: 800,
        color: '#444',
        background: '#1A1A1A',
        borderWidth: 1,
        borderStyle: 'solid',
        borderColor: '#222',
        borderRadius: 2,
        padding: '1px 4px',
        letterSpacing: '0.04em',
      }}
    >
      DONE
    </span>
  );
}

export function VideoInbox({ channel, videos, selectedVideoId, onVideoSelect }: Props) {
  const [tab, setTab] = useState<Tab>('new');

  const newVideos = videos.filter((v) => v.status === 'new');
  const managedVideos = videos.filter((v) => v.status === 'rendering' || v.status === 'done');
  const displayVideos = tab === 'new' ? newVideos : managedVideos;

  return (
    <div
      className="flex flex-col h-full shrink-0"
      style={{ width: 280, background: '#121212', borderRight: '1px solid #1E1E1E' }}
    >
      {/* Header */}
      <div
        className="px-5 flex items-center justify-between"
        style={{ height: 44, borderBottomWidth: 1, borderBottomStyle: 'solid', borderBottomColor: '#1E1E1E', background: '#0D0D0D' }}
      >
        <div className="flex items-center gap-2.5 min-w-0">
          <div
            style={{
              width: 10,
              height: 10,
              borderRadius: 2,
              background: channel.avatarColor,
              flexShrink: 0,
              boxShadow: `0 0 10px ${channel.avatarColor}66`,
            }}
          />
          <span
            className="truncate"
            style={{ fontSize: 11, fontWeight: 800, color: '#DDD', letterSpacing: '0.02em' }}
          >
            {channel.name.toUpperCase()}
          </span>
        </div>
        <div style={{ fontSize: 9, color: '#333', fontWeight: 700 }}>{videos.length} VIDS</div>
      </div>

      {/* Tabs */}
      <div
        className="flex shrink-0 bg-[#0F0F0F]"
        style={{ borderBottomWidth: 1, borderBottomStyle: 'solid', borderBottomColor: '#1E1E1E', padding: '0 4px' }}
      >
        {(['new', 'managed'] as Tab[]).map((t) => {
          const label = t === 'new' ? 'INBOX' : 'RENDERED';
          const isActive = tab === t;
          const count = t === 'new' ? newVideos.length : managedVideos.length;
          return (
            <button
              key={t}
              onClick={() => setTab(t)}
              style={{
                flex: 1,
                height: 32,
                background: 'transparent',
                borderWidth: 0,
                color: isActive ? '#00B4FF' : '#444',
                fontSize: 9,
                fontWeight: 800,
                letterSpacing: '0.1em',
                cursor: 'pointer',
                transition: 'all 0.2s',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 6
              }}
            >
              {label}
              <span style={{ 
                fontSize: 8, 
                padding: '1px 4px', 
                borderRadius: 2, 
                background: isActive ? '#00B4FF22' : '#1A1A1A',
                color: isActive ? '#00B4FF' : '#333'
              }}>{count}</span>
            </button>
          );
        })}
      </div>

      {/* Video list */}
      <div className="flex-1 overflow-y-auto">
        {displayVideos.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-32 gap-2">
            <span style={{ fontSize: 22, opacity: 0.15 }}>{tab === 'new' ? '📥' : '📦'}</span>
            <span style={{ fontSize: 11, color: '#333' }}>
              {tab === 'new' ? 'Không có video mới' : 'Chưa có video đã xử lý'}
            </span>
          </div>
        ) : (
          displayVideos.map((video) => {
            const isSelected = video.id === selectedVideoId;
            return (
              <VideoRow
                key={video.id}
                video={video}
                isSelected={isSelected}
                onSelect={() => onVideoSelect(video)}
              />
            );
          })
        )}
      </div>
    </div>
  );
}

function VideoRow({ video, isSelected, onSelect }: { video: Video; isSelected: boolean; onSelect: () => void }) {
  return (
    <button
      onClick={onSelect}
      className="w-full text-left block transition-colors group"
      style={{
        background: isSelected ? '#0D1F30' : 'transparent',
        borderLeft: isSelected ? '2px solid #00B4FF' : '2px solid transparent',
        borderBottom: '1px solid #181818',
        padding: '10px 12px 10px 14px',
        cursor: 'pointer',
        outline: 'none',
      }}
      onMouseEnter={(e) => {
        if (!isSelected) (e.currentTarget as HTMLButtonElement).style.background = '#161616';
      }}
      onMouseLeave={(e) => {
        if (!isSelected) (e.currentTarget as HTMLButtonElement).style.background = 'transparent';
      }}
    >
      <div className="flex items-start gap-2.5">
        {/* Mini thumbnail */}
        <div
          style={{
            width: 56,
            height: 32,
            borderRadius: 3,
            overflow: 'hidden',
            flexShrink: 0,
            background: '#111',
            borderWidth: 1,
            borderStyle: 'solid',
            borderColor: '#222',
          }}
        >
          <img
            src={video.thumbnail}
            alt=""
            style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}
          />
        </div>

        {/* Info */}
        <div className="flex-1 min-w-0">
          <div
            style={{
              fontSize: 11,
              color: isSelected ? '#fff' : '#bbb',
              fontWeight: isSelected ? 500 : 400,
              lineHeight: 1.4,
              marginBottom: 4,
              display: '-webkit-box',
              WebkitLineClamp: 2,
              WebkitBoxOrient: 'vertical',
              overflow: 'hidden',
            }}
          >
            {video.title}
          </div>
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5">
              <span style={{ fontSize: 9, color: '#444', fontFamily: 'monospace' }}>{video.downloadedAt}</span>
              <span style={{ fontSize: 9, color: '#333' }}>·</span>
              <span style={{ fontSize: 9, color: '#444', fontFamily: 'monospace' }}>{video.duration}</span>
            </div>
            <StatusPill status={video.status} progress={video.renderProgress} />
          </div>
          {/* Render progress bar */}
          {video.status === 'rendering' && video.renderProgress !== undefined && (
            <div style={{ marginTop: 4, height: 2, background: '#1A1A1A', borderRadius: 1 }}>
              <div
                style={{
                  width: `${video.renderProgress}%`,
                  height: '100%',
                  background: '#00B4FF',
                  borderRadius: 1,
                  transition: 'width 0.5s',
                }}
              />
            </div>
          )}
        </div>
      </div>

      {/* Quick Edit label (shows only on hover/selected) */}
      <div
        className="flex justify-end mt-1.5"
        style={{ opacity: isSelected ? 1 : 0, transition: 'opacity 0.15s' }}
      >
        <span
          style={{
            fontSize: 9,
            color: '#00B4FF',
            fontWeight: 600,
            letterSpacing: '0.08em',
          }}
        >
          QUICK EDIT →
        </span>
      </div>
    </button>
  );
}
