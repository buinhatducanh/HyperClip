import { useState } from 'react';
import { Channel, SystemStats } from '../types';

interface Props {
  channels: Channel[];
  activeChannelId: string;
  newCounts: Record<string, number>;
  onChannelSelect: (id: string) => void;
  onAddChannel: (url: string) => void;
  systemStats: SystemStats;
}

export function Sidebar({ channels, activeChannelId, newCounts, onChannelSelect, onAddChannel, systemStats }: Props) {
  const [addOpen, setAddOpen] = useState(false);
  const [urlInput, setUrlInput] = useState('');

  const submit = () => {
    if (!urlInput.trim()) return;
    onAddChannel(urlInput.trim());
    setUrlInput('');
    setAddOpen(false);
  };

  const ramPct = Math.round((systemStats.ramUsed / systemStats.ramTotal) * 100);

  return (
    <div
      className="flex flex-col h-full select-none shrink-0"
      style={{ width: 220, background: '#161616', borderRight: '1px solid #1E1E1E' }}
    >
      {/* App brand */}
      <div
        className="flex items-center gap-2 px-4"
        style={{ height: 48, borderBottom: '1px solid #1E1E1E' }}
      >
        <div
          className="flex items-center justify-center rounded"
          style={{ width: 22, height: 22, background: '#00B4FF', flexShrink: 0 }}
        >
          <svg width="10" height="10" viewBox="0 0 10 10"><polygon points="1,1 9,5 1,9" fill="white" /></svg>
        </div>
        <span style={{ fontSize: 11, fontWeight: 700, color: '#fff', letterSpacing: '0.06em' }}>AUTO-RENDER</span>
      </div>

      {/* Add tracker button */}
      <div className="px-3 py-2" style={{ borderBottom: '1px solid #1E1E1E' }}>
        {!addOpen ? (
          <button
            onClick={() => setAddOpen(true)}
            className="w-full flex items-center gap-2 rounded px-3 transition-colors"
            style={{
              height: 30,
              background: 'rgba(0,180,255,0.1)',
              border: '1px solid rgba(0,180,255,0.25)',
              color: '#00B4FF',
              fontSize: 11,
              fontWeight: 600,
              cursor: 'pointer',
              letterSpacing: '0.04em',
            }}
          >
            + Add Tracker
          </button>
        ) : (
          <div className="flex gap-1">
            <input
              autoFocus
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') submit(); if (e.key === 'Escape') setAddOpen(false); }}
              placeholder="youtube.com/@channel"
              className="flex-1 rounded px-2 outline-none"
              style={{
                height: 30,
                background: '#111',
                border: '1px solid #333',
                color: '#ddd',
                fontSize: 11,
                minWidth: 0,
              }}
            />
            <button
              onClick={submit}
              style={{
                width: 30,
                height: 30,
                background: '#00B4FF',
                border: 'none',
                borderRadius: 4,
                color: '#fff',
                fontSize: 16,
                cursor: 'pointer',
                flexShrink: 0,
              }}
            >
              ↵
            </button>
          </div>
        )}
      </div>

      {/* Channel list */}
      <div className="flex-1 overflow-y-auto">
        <div
          className="px-4 pt-3 pb-1"
          style={{ fontSize: 9, letterSpacing: '0.15em', color: '#444', fontWeight: 700 }}
        >
          TRACKED CHANNELS
        </div>
        {channels.map((ch) => {
          const isActive = ch.id === activeChannelId;
          const count = newCounts[ch.id] ?? 0;
          return (
            <button
              key={ch.id}
              onClick={() => onChannelSelect(ch.id)}
              className="w-full flex items-center gap-2.5 px-3 py-2 text-left transition-colors"
              style={{
                background: isActive ? 'rgba(0,180,255,0.07)' : 'transparent',
                borderLeft: isActive ? '2px solid #00B4FF' : '2px solid transparent',
                cursor: 'pointer',
              }}
            >
              <div
                className="flex items-center justify-center rounded shrink-0"
                style={{
                  width: 28,
                  height: 28,
                  background: ch.avatarColor + '22',
                  border: `1px solid ${ch.avatarColor}44`,
                  fontSize: 11,
                  fontWeight: 700,
                  color: ch.avatarColor,
                }}
              >
                {ch.name.charAt(0)}
              </div>
              <div className="flex-1 min-w-0">
                <div
                  className="truncate"
                  style={{ fontSize: 12, color: isActive ? '#fff' : '#888', fontWeight: isActive ? 600 : 400 }}
                >
                  {ch.name}
                </div>
                <div style={{ fontSize: 9, color: '#444' }}>{ch.handle}</div>
              </div>
              {count > 0 && (
                <div
                  className="flex items-center justify-center rounded-full shrink-0"
                  style={{
                    minWidth: 18,
                    height: 18,
                    background: '#00B4FF',
                    fontSize: 9,
                    fontWeight: 700,
                    color: '#000',
                    padding: '0 4px',
                  }}
                >
                  {count}
                </div>
              )}
            </button>
          );
        })}
      </div>

      {/* System monitor */}
      <div className="px-3 py-3" style={{ borderTop: '1px solid #1E1E1E' }}>
        <div style={{ fontSize: 9, letterSpacing: '0.15em', color: '#444', fontWeight: 700, marginBottom: 8 }}>
          SYSTEM
        </div>

        {/* RAM */}
        <StatRow
          label="RAM Disk"
          value={`${systemStats.ramUsed.toFixed(1)}/${systemStats.ramTotal}GB`}
          percent={ramPct}
          color={ramPct > 80 ? '#FF4444' : '#00B4FF'}
        />

        {/* GPU */}
        <StatRow
          label="GPU NVENC"
          value={`${systemStats.gpuUsage}% · ${systemStats.gpuTemp}°C`}
          percent={systemStats.gpuUsage}
          color={systemStats.gpuUsage > 90 ? '#FF4444' : '#00FF88'}
        />

        {/* Network */}
        <div className="flex items-center justify-between mt-1.5">
          <span style={{ fontSize: 10, color: '#555' }}>Net Route</span>
          <div className="flex items-center gap-1.5">
            <div
              style={{
                width: 6,
                height: 6,
                borderRadius: '50%',
                background: systemStats.isOnline ? '#00FF88' : '#FF4444',
                boxShadow: systemStats.isOnline ? '0 0 4px #00FF88' : 'none',
              }}
            />
            <span style={{ fontSize: 10, color: systemStats.isOnline ? '#00FF88' : '#FF4444', fontFamily: 'monospace' }}>
              {systemStats.networkIp}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatRow({ label, value, percent, color }: { label: string; value: string; percent: number; color: string }) {
  return (
    <div className="mb-2">
      <div className="flex justify-between mb-0.5">
        <span style={{ fontSize: 10, color: '#555' }}>{label}</span>
        <span style={{ fontSize: 10, color: '#666', fontFamily: 'monospace' }}>{value}</span>
      </div>
      <div style={{ height: 3, background: '#1E1E1E', borderRadius: 2 }}>
        <div
          style={{
            width: `${Math.min(percent, 100)}%`,
            height: '100%',
            background: color,
            borderRadius: 2,
            transition: 'width 0.8s ease',
          }}
        />
      </div>
    </div>
  );
}
