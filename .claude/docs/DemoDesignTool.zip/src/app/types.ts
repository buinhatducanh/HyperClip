export type VideoStatus = 'new' | 'rendering' | 'done';
export type CanvasBg = 'black' | 'white';

export interface Channel {
  id: string;
  name: string;
  handle: string;
  avatarColor: string;
}

export interface Video {
  id: string;
  channelId: string;
  title: string;
  thumbnail: string;
  duration: string;
  downloadedAt: string;
  status: VideoStatus;
  renderProgress?: number;
  fileSize: string;
}

export interface EditorState {
  canvasBg: CanvasBg;
  trimStart: number;
  trimEnd: number;
  overlayText: string;
  overlayBorderColor: string;
  overlayBgColor: string;
  overlayPosition: { x: number; y: number };
  overlayWidth: number;
  overlayFontSize: number;
  videoHeight: number;
  videoYOffset: number;
  speedMultiplier: 1.0 | 1.1 | 1.2;
  uploadedImageUrl: string | null;
}

export interface SystemStats {
  ramUsed: number;
  ramTotal: number;
  gpuUsage: number;
  gpuTemp: number;
  networkIp: string;
  isOnline: boolean;
}
