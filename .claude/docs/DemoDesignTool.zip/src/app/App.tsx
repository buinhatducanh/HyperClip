import { useState, useEffect, useCallback, useRef } from 'react';
import { Sidebar } from './components/Sidebar';
import { VideoInbox } from './components/VideoInbox';
import { DetailEditor } from './components/DetailEditor';
import { Channel, Video, SystemStats, EditorState } from './types';

// ─── Mock data ────────────────────────────────────────────────────────────────
const CHANNELS: Channel[] = [
  { id: 'ch1', name: 'TechViet Daily',  handle: '@techvietdaily',  avatarColor: '#00B4FF' },
  { id: 'ch2', name: 'GamingVN Pro',    handle: '@gamingvnpro',    avatarColor: '#7C3AED' },
  { id: 'ch3', name: 'FitnessGoal VN',  handle: '@fitnessgoalvn',  avatarColor: '#00FF88' },
  { id: 'ch4', name: 'Wanderlust VN',   handle: '@wanderlustvn',   avatarColor: '#FF6B35' },
  { id: 'ch5', name: 'Beat Studio',     handle: '@beatstudio',     avatarColor: '#FF0080' },
];

const INITIAL_VIDEOS: Video[] = [
  // TechViet Daily
  { id: 'v1', channelId: 'ch1', title: 'Top 10 Xu Hướng AI Sẽ Thay Đổi Thế Giới Năm 2025',
    thumbnail: 'https://images.unsplash.com/photo-1746608942838-a484d55ffeda?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400',
    duration: '12:34', downloadedAt: 'Hôm nay, 14:30', status: 'new', fileSize: '1.2 GB' },
  { id: 'v2', channelId: 'ch1', title: 'Học Python Từ Đầu — Zero To Hero Full Course 2025',
    thumbnail: 'https://images.unsplash.com/photo-1509701852059-c221a6f1e878?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400',
    duration: '8:22', downloadedAt: 'Hôm nay, 09:15', status: 'new', fileSize: '890 MB' },
  { id: 'v3', channelId: 'ch1', title: 'Review MacBook M3 Pro Sau 6 Tháng Sử Dụng Thực Tế',
    thumbnail: 'https://images.unsplash.com/photo-1723987251277-18fc0a1effd0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400',
    duration: '15:10', downloadedAt: 'Hôm qua, 22:45', status: 'done', fileSize: '1.5 GB' },

  // GamingVN Pro
  { id: 'v4', channelId: 'ch2', title: 'Best Gaming Setup 2025 — Tiết Lộ Full Dàn Máy Triệu Đô',
    thumbnail: 'https://images.unsplash.com/photo-1632603093711-0d93a0bcc6cc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400',
    duration: '22:15', downloadedAt: 'Hôm nay, 11:00', status: 'new', fileSize: '2.1 GB' },
  { id: 'v5', channelId: 'ch2', title: 'Top 5 Games Hay Nhất Tháng Này — Đừng Bỏ Lỡ',
    thumbnail: 'https://images.unsplash.com/photo-1746608942838-a484d55ffeda?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400',
    duration: '18:45', downloadedAt: '20 Thg 4', status: 'done', fileSize: '1.8 GB' },

  // FitnessGoal
  { id: 'v6', channelId: 'ch3', title: '30 Phút Tập Full Body Không Dụng Cụ — Đốt Mỡ Tối Đa',
    thumbnail: 'https://images.unsplash.com/photo-1734189605012-f03d97a4d98f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400',
    duration: '31:00', downloadedAt: 'Hôm nay, 08:00', status: 'new', fileSize: '2.4 GB' },
  { id: 'v7', channelId: 'ch3', title: 'Chế Độ Ăn Keto Cho Người Việt — Thực Đơn 7 Ngày Chi Tiết',
    thumbnail: 'https://images.unsplash.com/photo-1758279745466-f5f4087a87d6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400',
    duration: '9:45', downloadedAt: 'Hôm qua', status: 'rendering', renderProgress: 48, fileSize: '780 MB' },
  { id: 'v8', channelId: 'ch3', title: 'Yoga Buổi Sáng 20 Phút — Tăng Năng Lượng Cho Cả Ngày',
    thumbnail: 'https://images.unsplash.com/photo-1697030131936-b31b5c7fc07c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400',
    duration: '25:20', downloadedAt: '19 Thg 4', status: 'done', fileSize: '1.9 GB' },

  // Wanderlust VN
  { id: 'v9', channelId: 'ch4', title: 'Khám Phá Đà Lạt 3 Ngày 2 Đêm — Chi Phí Toàn Bộ',
    thumbnail: 'https://images.unsplash.com/photo-1697030131936-b31b5c7fc07c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400',
    duration: '18:30', downloadedAt: 'Hôm nay, 13:20', status: 'new', fileSize: '1.6 GB' },
  { id: 'v10', channelId: 'ch4', title: 'Một Ngày Ở Hội An — Ăn Gì, Đi Đâu, Chi Bao Nhiêu?',
    thumbnail: 'https://images.unsplash.com/photo-1678356434281-0ef01a3ac02d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400',
    duration: '14:55', downloadedAt: 'Hôm nay, 10:05', status: 'new', fileSize: '1.3 GB' },

  // Beat Studio
  { id: 'v11', channelId: 'ch5', title: 'Beat Lofi Chill Việt Nam Vol.3 — 1 Giờ Học Bài',
    thumbnail: 'https://images.unsplash.com/photo-1678356434281-0ef01a3ac02d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400',
    duration: '1:02:30', downloadedAt: 'Hôm nay, 07:00', status: 'new', fileSize: '3.2 GB' },
  { id: 'v12', channelId: 'ch5', title: 'Studio Tour 2025 — Setup Phòng Thu Mới Build Xong',
    thumbnail: 'https://images.unsplash.com/photo-1632603093711-0d93a0bcc6cc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400',
    duration: '11:20', downloadedAt: '18 Thg 4', status: 'done', fileSize: '950 MB' },
];

const INIT_EDITOR: EditorState = {
  canvasBg: 'black',
  trimStart: 0,
  trimEnd: 100,
  overlayText: '',
  overlayBorderColor: '#00B4FF',
  overlayBgColor: 'rgba(0, 180, 255, 0.1)',
  overlayPosition: { x: 50, y: 80 },
  overlayWidth: 80,
  overlayFontSize: 11,
  videoHeight: 32,
  videoYOffset: 50,
  speedMultiplier: 1.0,
  uploadedImageUrl: null,
};

const INIT_STATS: SystemStats = {
  ramUsed: 11.4, ramTotal: 32,
  gpuUsage: 76, gpuTemp: 71,
  networkIp: '192.168.1.105',
  isOnline: true,
};

// ─── App ──────────────────────────────────────────────────────────────────────
export default function App() {
  const [channels, setChannels] = useState<Channel[]>(CHANNELS);
  const [videos, setVideos] = useState<Video[]>(INITIAL_VIDEOS);
  const [activeChannelId, setActiveChannelId] = useState('ch1');
  const [selectedVideoId, setSelectedVideoId] = useState<string | null>(null);
  const [editorState, setEditorState] = useState<EditorState>(INIT_EDITOR);
  const [systemStats, setSystemStats] = useState<SystemStats>(INIT_STATS);
  const [toast, setToast] = useState('');
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Simulate render progress
  useEffect(() => {
    const id = setInterval(() => {
      setVideos((prev) =>
        prev.map((v) => {
          if (v.status !== 'rendering' || v.renderProgress === undefined) return v;
          const next = Math.min(v.renderProgress + Math.floor(Math.random() * 4) + 1, 100);
          if (next >= 100) return { ...v, status: 'done', renderProgress: undefined, downloadedAt: 'Vừa xong' };
          return { ...v, renderProgress: next };
        })
      );
    }, 2000);
    return () => clearInterval(id);
  }, []);

  // Simulate system stats drift
  useEffect(() => {
    const id = setInterval(() => {
      setSystemStats((s) => ({
        ...s,
        ramUsed: Math.max(8, Math.min(30, s.ramUsed + (Math.random() - 0.5) * 0.5)),
        gpuUsage: Math.max(40, Math.min(99, s.gpuUsage + Math.floor((Math.random() - 0.5) * 8))),
        gpuTemp: Math.max(60, Math.min(85, s.gpuTemp + Math.floor((Math.random() - 0.5) * 2))),
      }));
    }, 3000);
    return () => clearInterval(id);
  }, []);

  const showToast = (msg: string) => {
    setToast(msg);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(''), 3200);
  };

  const handleChannelSelect = useCallback((id: string) => {
    setActiveChannelId(id);
    setSelectedVideoId(null);
    setEditorState(INIT_EDITOR);
  }, []);

  const handleVideoSelect = useCallback((video: Video) => {
    setSelectedVideoId(video.id);
    setEditorState(INIT_EDITOR);
  }, []);

  const handleAddChannel = useCallback((url: string) => {
    const raw = url.replace(/^https?:\/\/(www\.)?youtube\.com\/@?/, '').split(/[/?]/)[0] || 'Kênh Mới';
    const name = raw.charAt(0).toUpperCase() + raw.slice(1);
    const colors = ['#FF6B35', '#7C3AED', '#00FF88', '#FF0080', '#FFB800', '#00B4FF'];
    const newCh: Channel = {
      id: `ch${Date.now()}`,
      name,
      handle: `@${raw.toLowerCase()}`,
      avatarColor: colors[channels.length % colors.length],
    };
    setChannels((prev) => [...prev, newCh]);
    setActiveChannelId(newCh.id);
    setSelectedVideoId(null);
    showToast(`✓ Đã thêm tracker: ${name}`);
  }, [channels.length]);

  const handleEditorChange = useCallback((patch: Partial<EditorState>) => {
    setEditorState((prev) => ({ ...prev, ...patch }));
  }, []);

  const handleRender = useCallback(() => {
    if (!selectedVideoId) return;
    setVideos((prev) =>
      prev.map((v) =>
        v.id === selectedVideoId ? { ...v, status: 'rendering', renderProgress: 0 } : v
      )
    );
    showToast('⚡ Đã thêm vào hàng render — GPU NVENC đang xử lý...');
  }, [selectedVideoId]);

  // Compute new counts per channel
  const newCounts: Record<string, number> = {};
  channels.forEach((ch) => {
    newCounts[ch.id] = videos.filter((v) => v.channelId === ch.id && v.status === 'new').length;
  });

  const activeChannel = channels.find((c) => c.id === activeChannelId)!;
  const channelVideos = videos.filter((v) => v.channelId === activeChannelId);
  const selectedVideo = videos.find((v) => v.id === selectedVideoId) ?? null;

  return (
    <div
      className="flex overflow-hidden"
      style={{ height: '100vh', background: '#0E0E0E', fontFamily: 'Inter, sans-serif', color: '#fff' }}
    >
      {/* Col 1 — Sidebar */}
      <Sidebar
        channels={channels}
        activeChannelId={activeChannelId}
        newCounts={newCounts}
        onChannelSelect={handleChannelSelect}
        onAddChannel={handleAddChannel}
        systemStats={systemStats}
      />

      {/* Col 2 — Video Inbox */}
      {activeChannel && (
        <VideoInbox
          channel={activeChannel}
          videos={channelVideos}
          selectedVideoId={selectedVideoId}
          onVideoSelect={handleVideoSelect}
        />
      )}

      {/* Col 3 — Detail Editor */}
      <DetailEditor
        video={selectedVideo}
        editorState={editorState}
        onChange={handleEditorChange}
        onRender={handleRender}
      />

      {/* Toast */}
      {toast && (
        <div
          style={{
            position: 'fixed',
            bottom: 24,
            right: 24,
            background: '#1A1A1A',
            borderWidth: '1px 1px 1px 3px',
            borderStyle: 'solid',
            borderColor: '#2A2A2A #2A2A2A #2A2A2A #00B4FF',
            borderRadius: 4,
            padding: '10px 16px',
            fontSize: 12,
            color: '#ccc',
            zIndex: 9999,
            boxShadow: '0 4px 24px rgba(0,0,0,0.5)',
            animation: 'toastIn 0.2s ease',
            maxWidth: 320,
          }}
        >
          {toast}
        </div>
      )}

      <style>{`
        @keyframes toastIn {
          from { opacity: 0; transform: translateY(8px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        * { box-sizing: border-box; }
        ::-webkit-scrollbar { width: 4px; height: 4px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #222; border-radius: 2px; }
        ::-webkit-scrollbar-thumb:hover { background: #333; }
        input[type=range] { -webkit-appearance: none; appearance: none; background: transparent; }
        input[type=range]::-webkit-slider-thumb { -webkit-appearance: none; }
        textarea { box-sizing: border-box; }
      `}</style>
    </div>
  );
}
