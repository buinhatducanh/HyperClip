
  # Set Main Language Vietnamese

  This is a code bundle for Set Main Language Vietnamese. The original project is available at https://www.figma.com/design/XnRjEjFXsxHSNQaFRJtlt1/Set-Main-Language-Vietnamese.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  